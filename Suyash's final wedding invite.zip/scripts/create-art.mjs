import { GoogleGenAI } from '@google/genai'
import { writeFileSync } from 'node:fs'
const ai = new GoogleGenAI({
  apiKey: process.env.NETLIFY_AI_GATEWAY_KEY,
  httpOptions: {
    baseUrl: process.env.NETLIFY_AI_GATEWAY_URL?.replace(/\/$/, ''),
  },
})
try {
  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-image',
    contents:
      'Create a refined Indian wedding invitation background illustration, landscape 16:9. Original delicate hand-painted watercolour on warm ivory textured paper, antique dusty gold and muted sage green with dusty rose florals. An ornate symmetrical Rajasthan palace with small domes and fine arches sits across the BOTTOM QUARTER with a terraced garden in front; lush watercolor flowering branches hang from both TOP CORNERS. The large CENTRAL and upper central 65 percent area is EMPTY ivory negative space for text. Very subtle elegant pale low-contrast artwork, exquisite Indian miniature painting details, botanical illustration. No text, no letters, no logos, no people.',
    config: { imageConfig: { aspectRatio: '16:9' } },
  })
  for (const part of response.candidates?.[0]?.content?.parts ?? [])
    if (part.inlineData) {
      writeFileSync(
        'public/img/palace.png',
        Buffer.from(part.inlineData.data, 'base64'),
      )
      console.log('Palace artwork saved')
    }
} catch {
  console.log('Artwork generation unavailable')
  process.exitCode = 1
}
