CREATE TABLE "wedding_rsvps" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"attendance" text NOT NULL,
	"attendees" integer NOT NULL,
	"ceremonies" jsonb NOT NULL,
	"message" text DEFAULT '' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
