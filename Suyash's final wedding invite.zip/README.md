# Radni Gade & Suyash — A Celebration of Love

An original, mobile-first Indian wedding invitation with burgundy letterpress stationery, rose silk ribbon accents, ivory and peach styling, a click-gated opening, a date reveal, live countdown, calendar download, family introductions, optional love story, five ceremonies, WhatsApp sharing, and a browser-only RSVP preview.

Built with React 19, TypeScript, TanStack Start, Vite, and Radix Dialog. No paid APIs are used by the running invitation. The palace illustration was generated for this project; no reference-site assets or code were copied.

## Personalise the invitation

Edit **`src/wedding.config.ts`**. It contains the couple’s names, family details, date, venue, story, music URL, RSVP deadline, and individual ceremonies. The invitation is personalised for Radni Gade and Suyash Joshi at Solitaire Banquets And Hotel in Nagpur. The celebrations take place on 4 and 5 December 2026; the existing wedding date of 5 December was retained for Vivaah Vidhi and Vivaah Muhurta & Mangalashtak. The story, dress codes, and RSVP deadline remain editable sample content.

- Keep dates in ISO format, including `+05:30` for India. All displayed ceremony dates use Asia/Kolkata; the countdown works for guests in every time zone.
- Update `date`, `endDate`, and `dateLabel` together. The calendar download uses `date` and `endDate`.
- Each ceremony has its own date, time, venue, address, dress code, colour, and Maps URL. The current ceremonies use the supplied Google Maps link for Solitaire Banquets And Hotel.
- Set a ceremony’s `enabled` to `false` to hide it from both the itinerary and RSVP.
- Set `story.enabled` to `false` to hide the story and its navigation link.
- Set `rsvpDeadline` to your response deadline.
- Shared-link titles and descriptions update from the configuration automatically.

## Invitation artwork

The original palace illustration is in `public/img/palace.png`. It is served through Netlify Image CDN. Change `heroImage` to replace it with another local image. Google Fonts are free; serif and sans-serif fallbacks remain available if fonts cannot load.

## Optional music

The supplied track is configured at `/music/wedding.m4a` and loops as background music. A visible play/pause control appears. Playback only starts after the guest presses Play; mobile browser autoplay restrictions are respected. An error appears if playback fails. To replace it, add an audio track to `public/music/` and update `musicUrl`; set it to an empty string to remove music.

## Run locally

Use Node 22.13+ (on Node 22) or Node 24+, and pnpm:

```sh
corepack enable
pnpm install
netlify link
netlify dev --port 8889
```

Choose your site when linking, then open `http://localhost:8889`.

## Browser-only RSVP

The RSVP interaction validates the guest name and celebration selection in the browser, then displays a thank-you message. It makes no backend requests, writes no database records, and does not store guest details in browser storage. Both the form and completion screen explain that responses are not sent or saved and guests must contact the hosts directly to confirm attendance.

The former RSVP endpoint and scheduled Google Sheets synchronization have been removed. Existing database records and previously applied migration files remain untouched; historical spreadsheet entries are not changed. This removes RSVP submission and synchronization activity, but does not establish whether the existing database or other site features incur charges. Review actual usage in the Netlify dashboard.

## Verify before sharing

Automated interaction tests are included in `src/components/invitation.test.tsx`. Run `pnpm test` in your own development environment. Tests cover opening, the date/countdown, local completion for each attendance choice, ceremony validation, and the absence of submission requests. These tests and a browser preview were not run during this editing session because this environment reserves validation for the deployment pipeline.

On the deployed preview, check:

1. Before opening, confirm only the stationery cover is present, with no navigation, countdown, RSVP form, or audio element. Tap to open, confirm the paper unfolds and keyboard focus moves to the invitation heading, then choose View invitation. With reduced motion enabled, confirm the invitation opens immediately without folding. Follow each header link and the mobile menu.
2. Reveal the date, watch the countdown tick, and open the downloaded `.ics` file in your calendar. A passed wedding date displays zeroes and a celebratory message.
3. Complete accept, maybe, and decline responses. Confirm the notice explains that no RSVP is sent or saved.
4. After loading the invitation, disconnect the network and complete the form. It should work locally with no RSVP request in the Network panel.
5. Open each Maps link, test WhatsApp sharing, and check your real venue addresses and timings.
6. Check a narrow phone, tablet, and desktop, keyboard-only navigation, and reduced-motion mode. If music is configured, verify Play and Pause on a phone.

Netlify’s deployment pipeline validates the production build. Only share the final HTTPS link after reviewing and replacing the sample details.
