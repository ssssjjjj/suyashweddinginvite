import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  jsonb,
} from 'drizzle-orm/pg-core'
export const rsvps = pgTable('wedding_rsvps', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  attendance: text('attendance').notNull(),
  attendees: integer('attendees').notNull(),
  ceremonies: jsonb('ceremonies').$type<string[]>().notNull(),
  message: text('message').notNull().default(''),
  createdAt: timestamp('created_at', { withTimezone: true })
    .defaultNow()
    .notNull(),
})
